var url = require('url')
var fs = require('fs/promises')
const http = require('http')
const hostname = '127.0.0.1'
const port = 3000
const server = http.createServer(async (req, res) => {
    //  console.log(req.url)
       var q = url.parse(req.url, true);
        var obj = q.query
        var res1 = parseInt(obj.txtnum1) + parseInt(obj.txtnum2)
        res.write(""+res1)
        await example(""+res1)

       // res.end("")
      })
     

async function example(data) {
  try {
    const content = data;
    await fs.writeFile('add.txt', content);
  } catch (err) {
    console.log(err);
  }
}
      server.listen(port, hostname, () => {
          console.log(`Server running at http://${hostname}:${port}/`)
        })

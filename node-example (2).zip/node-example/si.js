const http = require('http')
const hostname='127.0.0.1'
const port=5000
const server = http.createServer((request,response)=>{
    response.statusCode=200

    response.setHeader('Content-Type','text/html')
    var p = 120000
    var r = 5.5
    var t = 2
    var si = (p*r*t)/100
    response.end(`result is ${si}`)
})
server.listen(port,hostname,()=>{
    console.log(`Server running at http://${hostname}:${port}/`)  
})